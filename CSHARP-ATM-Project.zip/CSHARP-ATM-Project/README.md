Project # CSHARP-ATM-Project

This file provides information about the project, including the windows form application interface of the ATM system and the C# OOP concepts to run the Application are embeded 
