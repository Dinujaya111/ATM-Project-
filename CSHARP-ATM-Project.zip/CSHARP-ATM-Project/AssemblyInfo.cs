// VBConversions Note: VB project level imports
using System.Diagnostics;
using System;
using System.Xml.Linq;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;
using Microsoft.VisualBasic;
using System.Data;
using System.Collections.Generic;
using System.Linq;
// End of VB project level imports

using System.Reflection;
using System.Runtime.InteropServices;


// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

// Review the values of the assembly attributes

[assembly:AssemblyTitle("atmsystem")]
[assembly:AssemblyDescription("")]
[assembly:AssemblyCompany("")]
[assembly:AssemblyProduct("atmsystem")]
[assembly:AssemblyCopyright("Copyright ©  2014")]
[assembly:AssemblyTrademark("")]

[assembly:ComVisible(false)]

//The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly:Guid("8f2fe687-19c9-4c8e-bcb1-557e95498980")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers
// by using the '*' as shown below:
// <Assembly: AssemblyVersion("1.0.*")>

[assembly:AssemblyVersion("1.0.0.0")]
[assembly:AssemblyFileVersion("1.0.0.0")]

